# flickhawk-fyp
Flick Hawk is an Amazon product hunting tool which helps Amazon sellers and virtual assistant to find out the winning products.
